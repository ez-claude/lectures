# Claude Code 마스터 설정

> 이 파일은 항상 로드됨. 세부 규칙은 rules/ 폴더 참조.

---

## 절대 규칙 (최우선)

1. **이모지 금지** - 텍스트로 대체 ([OK], [FAIL], [Step])
2. **한글 응답** - 모든 출력은 한글
3. **버전 잠금** - state/versions.json 우선
4. **보안 필수** - API 키 환경변수만, 하드코딩 금지
5. **EazyCheck v5.1** - Build Mode에서 GATE + DMAD 토론(3-5파일 자문자답, 6+파일 2라운드 자문자답) + sim deep(3+파일 실패 시뮬레이션) 강제 실행
6. **기록 전 검증** - 파일에 사실을 기록할 때, 도구로 확인 가능한 것(날짜, 경로, 버전 등)은 반드시 도구로 확인 후 기록. 컨텍스트/이전 세션 데이터는 현재 시점과 다를 수 있으므로 신뢰 금지.

---

## [BOOT] 세션 시작 시 강제 Read

> 매 세션 첫 응답 전 반드시 실행. BOOT 미완료 시 작업 시작 금지.

### BOOT 1: 라우팅 규칙 (Plan-Deep / Build)

```
Read: C:/Users/user/.claude/state/routing.json → departments, triggers 섹션
→ [BOOT 1 통과] 에이전트 부서, 트리거 키워드, 모델 라우팅 로드
```

### BOOT 2: 패턴 로드 (Build 전용)

```
Read: C:/Users/user/.claude/projects/c--Users-user-Desktop-gpt/memory/patterns/INDEX.json
→ 현재 작업 목적과 매칭되는 패턴 파일 식별
→ _common.json (항상) + 매칭 파일 Read
→ [BOOT 2 통과] 패턴 로드 완료
```

---

## [EazyCheck v5] 코드 생성 전후 검증

> 상세: rules/eazycheck-v5.md

### GATE -1: Pre-Plan Gate
플랜 품질 검증. ExitPlanMode 전 자동 실행.
5개 체크: 경쟁분석 / 근본원인 / 품질기준 / 도메인규칙 / 검증방법 -> 3개 미만 시 차단

### GATE: 코드 전 정보 로드 (필수!)
```
Read: C:/Users/user/.claude/state/versions.json
Read: C:/Users/user/.claude/state/patterns.json
-> [GATE 통과] 버전 확인 + 관련 패턴 경고 출력
```

### [필수] 3+ 파일 변경 감지 시 토론 강제

**코드 작성 전 파일 수 판단 필수. 3개 이상 파일 생성/수정 예상 시 토론 없이 코드 작성 금지!**

```
[0] 버그/에러 키워드 감지 시 → 역추적 먼저 (6+ 파일 제외, sim S2가 커버)
    트리거: 에러, 오류, 안되, 안됨, 문제, 실패, 버그, 왜, 500, 404, 터짐, crash, fail
    [역추적]
    증상: {에러/문제 1줄}
    경로: {어떤 입력 → 어디를 거쳐 → 여기서 터짐}
    수정 위치: {근본 원인 위치 확정}
    → 수정 위치 확정 후 코드 작성

[1] 파일 수 판단: "이 작업에서 몇 개 파일을 생성/수정하는가?"
    -> 1-2개: 바로 코드 작성
    -> 3-5개 + 신규기능/복합수정: DMAD 자문자답 1라운드 -> 코드 -> sim deep 1회
    -> 3-5개 + 설정/배포/리팩토링: 토론 스킵 -> 코드 -> sim deep 1회
    -> 6개+: DMAD 토론 2라운드 -> 코드 -> sim deep 루프 (최대 2회)

[2] DMAD 토론 (설계자 vs 사용자, 추론 방향이 다른 문답)
    [강제] 토론 시작 전 변경 대상 파일 + 직접 의존 파일 전부 Read
           파일 읽기 없이 토론 시작 금지 (기억으로 코드 언급 금지)
    [필수] 문제 제기 시 코드 라인 직접 인용: `파일명:라인: 코드내용`
           인용 없는 주장 금지 (오독 할루시네이션 방지)
    [설계자 - 순방향] 기술적 최선 추구
      Q1. 더 단순한 방법이 있나?
      Q2. 기존 코드 어디와 부딪히나?
      Q3. 가장 위험한 가정 하나는?
      Q4. 기존 코드베이스에 중복 로직?
    [사용자 - 역방향] 실제 사용 경험 관점
      Q1. 처음 보는 사람이 이 기능을 찾고 쓸 수 있나?
      Q2. 기대하는 방식으로 동작?
      Q3. 실패 시 스스로 해결?
      Q4. 에러가 조용히 삼켜지는 곳?
    규칙: 전부 수긍 금지, 매 라운드 반례 1개 이상
    -> [토론 결과] 출력 후 코드 작성 시작

[3] 코드 작성

[4] sim deep (코드 후, 장기 실패 시뮬레이션)
    S1. 3개월+10배 상황에서 코드 따라가며 터지는 곳 찾기
    S2. 근본 원인 + 같은 유형 전체 탐색
    S3. 수정 -> 확인 시뮬레이션 (최대 2회 루프)
    -> 2회 후에도 실패 시: 사용자 승인 -> 디버깅 모드 전환
```

**스킵 허용 조건** (반드시 사유 출력):
- 동일 패턴 반복 적용 (리네이밍, 포맷팅)
- 기존 플랜 기반 실행 중 (플랜에서 이미 설계 검토 완료)
- 사용자가 "토론 스킵" 명시 요청
- 설정/배포/단순 리팩토링 (신규 기능 없는 3-5파일 변경)

**스킵 시 출력:**
```
[토론 스킵] 사유: {구체적 사유}
```

### 1-2 파일 변경 시: 바로 코드 작성
```
[코드 작성] (토론/sim deep 없음)
```

### POST-BUILD: 종합 확인
```
[검증]
[A] versions.json 일치: [OK/FAIL]
[B] patterns.json 위반: [OK/FAIL]
[C] API 키 하드코딩: [OK/FAIL]
[D] import 누락: [OK/FAIL]
결과: {N}개 문제 / 통과
```

---

## [DEBUGGING] 근본 원인 분석

> 스킬 `systematic-debugging` 기반. 트리거 키워드 감지 시 필수 실행.

### 트리거 키워드

"아직도", "똑같아", "그대론데", "달라진게 없는데", "여전히", "안 바뀌었어", "같은 에러", "또"

### 필수 실행 순서

```
[1/5] Read: C:/Users/user/.claude/hooks/debug_trigger.json → 패턴 매칭
[2/5] 문제 유형 식별
[3/5] 해당 도구 실행 (debug_subtitle_flow.py / debug_data_flow.py / check_final.py)
[4/5] 실행 결과 분석 (추측 금지! 데이터 기반만)
[5/5] 사용자에게 보고: 원인 + 근거 + 해결 방안
```

### 강제 규칙

- [금지] debug_trigger.json 읽지 않고 코드 수정
- [금지] "아마도", "~인 것 같습니다" 추측성 표현
- [필수] 도구 실행 결과 → 원인 분석 → 수정 제안 (순서 엄수)

> 상세 예시/체크리스트: `systematic-debugging` 스킬 참조
> /debug 커맨드: `C:/Users/user/.claude/tools/auto_debugger.py` 사용

---

## [COMMIT] 검증 후 커밋

> 스킬 `verification-before-completion` + `finishing-a-development-branch` 기반

"완료", "배포", "커밋" 감지 시:
1. 현재 프로젝트 루트에서 `check_final.py` 실행 (있는 경우)
2. Semgrep/E2E FAIL → 커밋 중단
3. 통과 시 git commit

> /c 커맨드로 검증+커밋 원스텝 실행

---

## 환경 정보

| 항목 | 값 |
|------|-----|
| OS | Windows 11 |
| IDE | VSCode |
| AI | Claude Max, Gemini, GPT |

---

## 세션 모드

| 모드 | 트리거 | 강제 Read |
|------|--------|----------|
| **Plan-Light** | "~할까?", 질문형 | BOOT 1만 |
| **Plan-Deep** | `/0`, "분석해줘" | BOOT 1 |
| **Build** | "만들어줘", 명령형 | BOOT 1 + BOOT 2 + GATE |

---

## 시스템 관리 파일

| 파일 | 역할 | 업데이트 시점 |
|------|------|-------------|
| `state/ai-system.json` | AI 시스템 레지스트리 (스킬/에이전트/룰/트리거) | 스킬 추가, 에이전트 변경, 트리거 추가 시 |
| `state/routing.json` | 라우팅 동작 규칙 (어떻게 작동하는지) | 트리거/라우팅 변경 시 |
| `state/SYSTEM_INDEX.md` | 전체 인덱스 (프로그램/인프라 포함) | 스크립트/인프라 변경 시 |

> "내 시스템 뭐 있어?" → ai-system.json 참조
> "전체 구조 보여줘" → SYSTEM_INDEX.md 참조

### 파일 형식 원칙

| 형식 | 용도 | 이유 |
|------|------|------|
| **MD** | 맥락이 필요한 설명/가이드 | 사람이 읽기 편함 |
| **JSON** | 수치화된 데이터/설정/목록 | 가볍고 빠르고 오류없이 읽힘 |

---

## Master Router (/0)

> 경로: `C:\Users\user\cognitive_engines\00_Master_Router.md`

- 희망적 부풀리기 금지, 데이터 기반 냉정한 분석
- 실패 가능성 명시, 대안 제시

```
가능성 있는 부분: [근거]
위험한 부분: [근거]
불가능한 부분: [근거]
→ 현실적 대안: [구체적 방안]
```

---

## 필수 보안 규칙

### Git Push 전 검증 (필수!)

```bash
grep -rE "(AIzaSy|sk-|ghp_|gho_|api_key\s*=)" --include="*.py" --include="*.js" --include="*.json" .
```

| 금지 패턴 | 올바른 방식 |
|----------|------------|
| `AIzaSy...` (Google) | `os.getenv('GOOGLE_API_KEY')` |
| `sk-...` (OpenAI) | `os.getenv('OPENAI_KEY')` |
| `ghp_...` (GitHub) | `os.getenv('GITHUB_TOKEN')` |

---

## 코드 리뷰

> 스킬 `requesting-code-review` + `receiving-code-review` 기반

핵심 원칙: 전체 검토 후 한꺼번에 보고 ("일단 이것만" 금지)
1. 입력 확인 → 2. 출력 확인 → 3. 구조 매칭 → 4. 전체 흐름

---

## 에이전트/라우팅

> BOOT 1에서 routing.json 강제 Read 시 자동 로드됨.
> 에이전트 부서: routing.json → departments
> 자동 트리거: routing.json → triggers
> 모델 라우팅: routing.json → modelRouting

---

## 세부 규칙 파일 (rules/)

| 파일 | 용도 | 로드 시점 |
|------|------|----------|
| eazycheck-v5.md | EazyCheck v5 (GATE+토론+sim+Check도구) | Build Mode |
| pattern-system.md | 사용자 패턴 축적-분석 시스템 | Hook 트리거 시 |
| paper-rag.md | 논문 RAG 시스템 (10개 논문) | 논문 키워드 감지 시 |
| storage-protocol.md | 저장 프로토콜 | 필요 시 |
| quick-commands.md | 빠른 명령어 | 필요 시 |

---

## 검증 시스템 역할 분리

| 상황 | 시스템 | 명령 |
|------|--------|------|
| 코드 생성 후 도구 검증 | EazyCheck (pre-commit, CI, E2E) | 자동 |
| 코드 후 시나리오 검증 (3+파일) | sim deep | 자동 |
| 커밋 전 전체 검증 | check_final.py | 자동 |
| QT 비즈니스 로직 | verify 스킬셋 | `/vi` |

---

## [PATTERN] 사용자 패턴 시스템

> Hook `pattern_trigger.py`가 긍정 표현 감지 시 자동 알림.
> 상세 규칙: `rules/pattern-system.md`
> 패턴 데이터: `memory/patterns/` (목적별 파일 + INDEX.json)
> 세션 시작 시: INDEX.json 읽고 현재 작업과 매칭되는 패턴 파일 로드

### 패턴 저장 우선 규칙 (필수!)
**"좋아" + 작업 요청이 동시에 올 때: 패턴 저장 먼저 → 작업 시작**
- [APPROVAL TRIGGER] 감지 시, 축적된 교정/원칙/거부/결정이 있으면 _buffer.json 저장을 먼저 실행
- 저장 완료 후 작업 시작 (1줄 보고: "[PATTERN] N개 저장 완료")
- 축적된 항목이 없으면 바로 작업 시작

---

## [SIM] 시스템 변경 자동 검증

> Hook `sim_trigger.py`가 시스템 파일(hooks/rules/state/skills/CLAUDE.md) 수정 3개+ 감지 시 알림.
> 알림 수신 시: `/sim` 스킬 절차대로 장기 시뮬레이션 자동 실행.
> 1-2개 수정은 무시 (사소한 변경).

---

## 작업 완료 체크리스트

- 보안 스캔 통과 (High 0)
- 빌드 경고 0개
- PR 링크 제공
- Git 브랜치: main
